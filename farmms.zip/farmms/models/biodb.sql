CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `pic` varchar(222) NOT NULL,
  `mobile` int(12) NOT NULL,
  `log_id` int(11) NOT NULL
);

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `first_name` varchar(80) NOT NULL,
    `middle_name`varchar(80),
    `surname` varchar(80) NOT NULL,
    `program` varchar(20),
    `year_os` SMALLINT(2),
    `reg_no` varchar(15) NOT NULL,
  `pic` varchar(222),
  `mobile` int(12) NOT NULL,
  `log_id` int(11) NOT NULL
) ;
CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `first_name` varchar(80) NOT NULL,
    `middle_name`varchar(80),
    `surname` varchar(80) NOT NULL,
    `staff_role` varchar(20),
    `office_id` SMALLINT(2),
    `staff_no` varchar(15) NOT NULL,
  `pic` varchar(222) NOT NULL,
  `mobile` int(12) NOT NULL,
  'finger_id' varchar UNIQUE,
  `log_id` int(11) NOT NULL
); 